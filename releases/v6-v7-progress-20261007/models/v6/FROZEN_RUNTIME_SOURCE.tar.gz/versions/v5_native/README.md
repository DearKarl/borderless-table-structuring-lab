# V6 direct regional scale controllers

Four CPU-trained controllers and six load-verified configurations are available in [the V6 package](../../artifacts/models/v6/PACKAGE_MANIFEST.json). Actual controller-selected OCR validation and full benchmark results are pending. Packaging does not establish an accuracy gain, official rank, or novelty.

| Configuration | Controller | Intervention |
|---|---|---|
| GBDT_V6.1.1 | GBDT | Tables |
| GBDT_V6.1.2 | GBDT | Formulas |
| GBDT_V6.1.3 | GBDT | Tables and formulas |
| MLP_V6.2.1 | MLP | Tables |
| MLP_V6.2.2 | MLP | Formulas |
| MLP_V6.2.3 | MLP | Tables and formulas |

The configurations share four task/family checkpoints. D0 is a shared default TeleOCR baseline. Each benchmark page has one native parse; the six derived outputs reuse it. Combined configurations reuse their family's component decisions and candidates. These are paired shared-computation outputs, not seven independent fresh runs.

## Input and prediction contract

[native.py](native.py) captures the image returned by unchanged TeleOCR `read_fn`/`do_parse`, with 200-DPI rendering and the native 3500-pixel cap (renderer rounding can produce 3501 pixels). Crops use those captured pixels and the native integer coordinate frame. There is no original RGB shortcut, source rerendering, cap increase, or formula 200/72 multiplier. Rendering DPI stays 200; regional pixel resize scale is learned.

[direct_controller.py](direct_controller.py) predicts one log-scale from the same 17 native-region features for both families, clips log-scale to log([0.5, 3]), exponentiates, and rounds pixel dimensions. There is no deployed scale menu, candidate loop, snapping, gain head, or OCR search. Nonfinite features/predictions or more than 64 million requested pixels retain native content. Each region receives at most one additional OCR request per family. Equal actual inputs can share OCR when pixel tensor, image-grid and prompt identities match.

[actor.py](actor.py) checks preview preprocessing against actual OCR tensors. The change reference is the same region's 1x preprocessing; equality with its earlier native page extraction input is not assumed. Unknown comparisons remain unknown. A changed nominal scale or output is not proof of improved recognition.

[assembly.py](assembly.py) derives each output from immutable native content. Accepted changes compete by table priority, larger area, then native order; overlap suppressions are recorded. Structural rejection retains native. The old multi-attempt guard is inactive. Failures retain each output's last atomic stage and remain in denominators. Completed or failed pages are not replayed.

## Frozen external data

The pool contains 276 reliably matched native predicted regions from 242 source documents: 110 formulas and 166 tables. It was built from 590 selected public examples, retaining a smaller reliable pool than the initial 3072-region target. Source-PDF correspondence and labels are offline; GT boxes/text never select inference regions or features.

| Split | Formulas | Tables | Regions | Documents |
|---|---:|---:|---:|---:|
| Train | 68 | 112 | 180 | 159 |
| Validation | 19 | 29 | 48 | 42 |
| Test | 23 | 25 | 48 | 41 |

Document groups are disjoint. Pilot split roles were preserved; new groups used a frozen source-hash assignment. Contribution was capped at four regions/source (actual maximum three). No duplicate native pixels or native units were found. Crop hash/near-duplicate and known benchmark source-ID checks do not prove contamination freedom.

Sources are [Image2Struct equations](https://huggingface.co/datasets/stanford-crfm/i2s-latex), revision `d889f4a4bed5d6394a5966e35f37686fae4070a2`, and [Docling PubTabNet-OTSL](https://huggingface.co/datasets/docling-project/PubTabNet_OTSL), revision `c6b519724c09c81dc4797b742826681ebf5c7dde`. Equations use the 300-record published validation split, repartitioned by document as disclosed here; published test data was not used. Tables were sampled across shards 0, 17 and 34, using original HTML/cell labels. These scientific-paper sources do not establish multilingual, scanned, financial or general-document coverage. Images, labels, raw predictions and deployment bindings remain outside public artifacts.

At most eight offline realized views supplied one best valid measured log-scale target per region, using TEDS for tables and CDM for formulas. Differences within 1e-6 tie; choose the measured scale closest to 1, then smaller. This is a sampled empirical optimum, not a certified continuous/global optimum. All 182 non-beneficial examples remain, with one training weight each. In 222 regions, multiple distinct measured inputs tied. All 276 regions obtained valid targets. Of 2208 planned views, 2207 completed with verified actual tensor identities; one over-context view failed without replay. Its other valid views and failure record were retained.

Fixed external controls were selected by common-coverage validation macro quality over the same offline scales: table 0.535299427146522, formula 1.25. Test quality did not select them. Actual learned-scale rereads and held-out quality comparisons are pending.

## Training and use

[direct_train.py](direct_train.py) fits log-scale squared error on matched rows, weights, features and training-only normalization. GBDT uses constant-leaf HistGradientBoosting: 100 iterations, maximum 15 leaves, minimum 20 samples/leaf, learning rate 0.05, L2=1, seed 0, no early stopping. The MLP has 64/32 ReLU layers and a scalar linear head; NumPy float64 CPU Adam, learning rate 0.001, weight decay 0.0001, batch 128, seed 0, maximum 200 epochs and validation patience 20. Target normalization uses training only.

The table MLP selected epoch 9 and stopped at 29; the formula MLP selected epoch 6 and stopped at 26. Four fits took about 0.19 seconds on this small dataset, excluding startup and packaging. No OCR weights were trained. Exported checkpoints exactly reproduced in-memory validation predictions; this validates loading, not OCR quality.

The [package manifest](../../artifacts/models/v6/PACKAGE_MANIFEST.json) records checkpoint/data hashes, split counts and load checks. Each named configuration includes source hashes, feature schema, dependencies and invocation. A JSON array of 17 native features can be evaluated with:

```text
python -m versions.v5_native.predict --package artifacts/models/v6/GBDT_V6.1.1.json --kind table --features native_features.json --width 100 --height 40
```

[shared_worker.py](shared_worker.py) is the bounded OCR execution entry. [external_actor_worker.py](external_actor_worker.py) runs actual learned/fixed actions on saved native validation/test regions. Historical response-model code in `controller.py`, `train.py` and parts of `matched_train.py` remains inactive for V6 deployment; the latter's tested optimizer/export helpers support direct training.

## Measurement and limits

The full comparison will retain 1651 pages per output: 9906 adaptive arm-page outputs, or 11557 including D0, from 1651 distinct pages. Sixteen deterministic technical-smoke pages contribute unchanged outputs; only the remaining 1635 pages are subsequently processed. Smoke acceptance checks runtime, lineage and assembly without a quality gate.

[evaluate.py](evaluate.py) retains Overall, Text Edit, Formula CDM, Formula Edit, Table TEDS, Table TEDS-S, Table Edit and Reading Order Edit where the pinned official evaluator emits them, plus category breakdowns. Missing fields are null with reasons. Activation reporting separates predict API calls/rows, nominal scale, requested pixels, verified tensors, physical/reused OCR, accepted edits and offline quality effects. Actual shared costs and estimated standalone costs are labeled separately.

TeleOCR source is pinned to `9921cffe380efe4e2fa010258b3d0c3cb70bab2d`; actual OCR asset hashes identify the runtime, while the requested upstream model revision remains unverified. Structural checks/reference mechanisms derive from [ki-OCR-v1](https://github.com/yushuosun/ki-OCR-v1), commit `ac1ab4f5ded8b025f47a7683f58e65db4ac43a2b`, through preserved V5 code. The official evaluator is pinned to `147cd5ac9472002f5751221d390bf00abdbc0d2f`, configuration hash `56db52659910273376223a5646eabfaff21b25dc30f434e1c90aab1a233d335a`.

GBDT and MLP differ in capacity, optimization and regularization as well as continuity. This comparison cannot isolate continuity as the cause of a difference; routing, pixel rounding and OCR are outside any continuity claim. A fixed-scale end-to-end counterfactual would be needed to isolate learned-scale benefit from rereading alone. Existing external fixed controls provide source-domain evidence only. Official-protocol local scoring is not an official leaderboard submission.
